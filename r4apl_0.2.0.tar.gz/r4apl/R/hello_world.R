#' Hello World Function
#'
#' This function prints 'Hello, World!'.
#' @export
hello_world <- function() {
  print("Hello, World!")
}